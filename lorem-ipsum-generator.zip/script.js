
function generateLoremIpsum() {
    const lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mollis, dolor eget aliquam fringilla, nisl nulla tincidunt eros, vitae pharetra eros enim a elit. Integer id metus.";
    document.getElementById('output').value = lorem;
}
